// Actualmente no se requiere JS para esta página
// Puedes usar este archivo para futuras funciones dinámicas